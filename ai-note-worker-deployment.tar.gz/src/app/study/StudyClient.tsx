"use client";

import React, { useEffect, useMemo, useState } from "react";
import { useToast } from "@/components/ToastContext";
import { FLASHCARD_COUNT_OPTIONS, FLASHCARD_FIELD_MAX_LEN } from "@/lib/flashcards-constants";
import { IconCheck, IconSparkles, IconXMark, IconChevronLeft, IconChevronRight } from "@/components/Icons";
import { formatIstDateTime } from "@/lib/datetime";

interface Flashcard {
  question: string;
  answer: string;
  hint?: string;
}

interface HistoryEntry {
  id: string;
  subject: string;
  topic: string;
  createdAt: string;
  cards: Flashcard[];
}

type CardStatus = "pending" | "checked" | "unchecked" | "skipped";

function LoadingDots() {
  return (
    <span className="inline-flex items-end gap-1 align-middle" aria-hidden="true">
      <span className="h-2 w-2 rounded-full bg-primary animate-bounce" />
      <span className="h-2 w-2 rounded-full bg-primary animate-bounce [animation-delay:150ms]" />
      <span className="h-2 w-2 rounded-full bg-primary animate-bounce [animation-delay:300ms]" />
    </span>
  );
}

const SUBJECT_OPTIONS = [
  "Mathematics",
  "Physics",
  "Chemistry",
  "Computer Science",
  "Biology",
  "Economics",
  "History",
];

export default function StudyClient() {
  const { showToast } = useToast();
  const [subject, setSubject] = useState<string>(SUBJECT_OPTIONS[0]);
  const [topic, setTopic] = useState<string>("");
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [cardStatus, setCardStatus] = useState<CardStatus[]>([]);
  const [flipped, setFlipped] = useState<boolean[]>([]);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [swipeOffset, setSwipeOffset] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const [swipeStartX, setSwipeStartX] = useState(0);
  const [count, setCount] = useState<number>(FLASHCARD_COUNT_OPTIONS[0]);
  const [loading, setLoading] = useState(false);
  const [limitUsed, setLimitUsed] = useState(0);
  const [limit, setLimit] = useState(5);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const remaining = useMemo(() => Math.max(limit - limitUsed, 0), [limit, limitUsed]);
  const checkedCount = useMemo(() => cardStatus.filter((s) => s === "checked").length, [cardStatus]);
  const uncheckedCount = useMemo(() => cardStatus.filter((s) => s === "unchecked").length, [cardStatus]);
  const skippedCount = useMemo(() => cardStatus.filter((s) => s === "skipped").length, [cardStatus]);
  const pendingCount = useMemo(() => cardStatus.filter((s) => s === "pending").length, [cardStatus]);
  const reviewedCount = useMemo(() => checkedCount + uncheckedCount, [checkedCount, uncheckedCount]);

  useEffect(() => {
    fetch("/api/study/flashcards")
      .then((res) => res.json())
      .then((data) => {
        if (typeof data.used === "number") setLimitUsed(data.used);
        else setLimitUsed(0);
        if (typeof data.limit === "number") setLimit(data.limit);
      })
      .catch((error) => {
        console.error("[study] Failed to load flashcard limits", error);
      });
    }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const stored = localStorage.getItem("flashcardHistory");
      if (stored) {
        const parsed = JSON.parse(stored) as HistoryEntry[];
        setHistory(parsed);
      }
    } catch (error) {
      console.warn("[study] Unable to read flashcard history", error);
    }
  }, []);

  const toggleFlip = (index: number) => {
    setFlipped((prev) => prev.map((v, i) => (i === index ? !v : v)));
  };

  const persistHistory = (entries: HistoryEntry[]) => {
    setHistory(entries);
    if (typeof window === "undefined") return;
    try {
      localStorage.setItem("flashcardHistory", JSON.stringify(entries));
    } catch (error) {
      console.warn("[study] Unable to persist flashcard history", error);
    }
  };

  const saveSessionToHistory = (cards: Flashcard[], subj: string, top: string) => {
    const entry: HistoryEntry = {
      id: `${Date.now()}`,
      subject: subj,
      topic: top,
      createdAt: new Date().toISOString(),
      cards,
    };
    const updated = [entry, ...history].slice(0, 5);
    persistHistory(updated);
  };

  const loadHistoryEntry = (entry: HistoryEntry) => {
    setSubject(entry.subject);
    setTopic(entry.topic);
    setFlashcards(entry.cards);
    resetCardState(entry.cards);
  };

  const markCard = (index: number, status: CardStatus) => {
    setCardStatus((prev) => prev.map((v, i) => (i === index ? status : v)));
    // Move to next card after marking
    if (index < flashcards.length - 1) {
      setTimeout(() => {
        setCurrentCardIndex(index + 1);
        setFlipped((prev) => prev.map((v, i) => (i === index + 1 ? false : v)));
      }, 300);
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setSwipeStartX(e.touches[0].clientX);
    setIsSwiping(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isSwiping) return;
    const currentX = e.touches[0].clientX;
    const diff = currentX - swipeStartX;
    setSwipeOffset(diff);
  };

  const handleTouchEnd = () => {
    if (!isSwiping) return;
    setIsSwiping(false);

    const threshold = 100;
    if (Math.abs(swipeOffset) > threshold) {
      if (swipeOffset > 0) {
        // Swipe right - mark as checked
        markCard(currentCardIndex, "checked");
      } else {
        // Swipe left - mark as unchecked
        markCard(currentCardIndex, "unchecked");
      }
    }
    setSwipeOffset(0);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setSwipeStartX(e.clientX);
    setIsSwiping(true);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isSwiping) return;
    const diff = e.clientX - swipeStartX;
    setSwipeOffset(diff);
  };

  const handleMouseUp = () => {
    if (!isSwiping) return;
    setIsSwiping(false);

    const threshold = 100;
    if (Math.abs(swipeOffset) > threshold) {
      if (swipeOffset > 0) {
        // Swipe right - mark as checked
        markCard(currentCardIndex, "checked");
      } else {
        // Swipe left - mark as unchecked
        markCard(currentCardIndex, "unchecked");
      }
    }
    setSwipeOffset(0);
  };

  const handleCardClick = () => {
    if (Math.abs(swipeOffset) < 5) {
      toggleFlip(currentCardIndex);
    }
  };

  const navigateToCard = (newIndex: number, markAsSkipped: boolean) => {
    if (newIndex >= 0 && newIndex < flashcards.length) {
      // Mark current card as skipped when moving forward without a decision
      if (markAsSkipped) {
        const currentStatus = cardStatus[currentCardIndex];
        if (currentStatus === "pending" || currentStatus === "skipped") {
          setCardStatus((prev) => prev.map((v, i) => (i === currentCardIndex ? "skipped" : v)));
        }
      }
      setCurrentCardIndex(newIndex);
      setFlipped((prev) => prev.map((v, i) => (i === newIndex ? false : v)));
      setSwipeOffset(0);
    }
  };

  const handlePrevCard = () => {
    if (currentCardIndex > 0) {
      navigateToCard(currentCardIndex - 1, false);
    }
  };

  const handleNextCard = () => {
    if (currentCardIndex < flashcards.length - 1) {
      navigateToCard(currentCardIndex + 1, true);
    }
  };

  const resetCardState = (cards: Flashcard[]) => {
    setCardStatus(cards.map(() => "pending"));
    setFlipped(cards.map(() => false));
    setCurrentCardIndex(0);
    setSwipeOffset(0);
  };

  const handleGenerate = async () => {
    if (!topic.trim()) {
      showToast("Please enter a topic to generate flashcards.", "warning");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/study/flashcards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject, topic, count }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (typeof data.used === "number") setLimitUsed(data.used);
        if (typeof data.limit === "number") setLimit(data.limit);
        showToast(data.error || "Unable to generate flashcards right now.", "error");
        return;
      }

      const cards: Flashcard[] = data.flashcards ?? [];
      setFlashcards(cards);
      resetCardState(cards);
      saveSessionToHistory(cards, subject, topic);
      setLimitUsed(typeof data.used === "number" ? data.used : 0);
      setLimit(typeof data.limit === "number" ? data.limit : limit);
      showToast("Flashcards generated successfully!", "success");
    } catch {
      showToast("Something went wrong. Please try again.", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-outline/10 bg-surface shadow-ambient">
        <div className="flex items-center justify-between border-b border-outline/10 px-6 py-4">
          <div>
            <p className="text-sm font-medium text-on-surface-variant">Daily Limit</p>
            <p className="text-xl font-semibold text-on-surface">
              Generations: {limitUsed} / {limit}
            </p>
          </div>
          <div className="rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            {remaining} remaining
          </div>
        </div>

        <div className="grid gap-4 px-6 py-6 md:grid-cols-[1fr,1fr,auto] md:items-end">
          <label className="space-y-2">
            <span className="text-sm font-semibold text-on-surface-variant">Subject</span>
            <select
              className="w-full rounded-xl border border-outline/20 bg-surface-variant px-4 py-3 text-on-surface shadow-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              disabled={loading}
            >
              {SUBJECT_OPTIONS.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </label>

          <label className="space-y-2">
            <span className="text-sm font-semibold text-on-surface-variant">Topic / Focus</span>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., Quantum Entanglement or Dynamic Programming"
              className="w-full rounded-xl border border-outline/20 bg-surface-variant px-4 py-3 text-on-surface placeholder:text-on-surface-variant/70 shadow-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
              disabled={loading}
              maxLength={FLASHCARD_FIELD_MAX_LEN}
            />
          </label>

          <div className="space-y-2 md:col-span-2">
            <span className="text-sm font-semibold text-on-surface-variant">Cards per run</span>
            <div className="flex flex-wrap gap-2">
              {FLASHCARD_COUNT_OPTIONS.map((option) => {
                const isActive = option === count;
                return (
                  <button
                    type="button"
                    key={option}
                    onClick={() => setCount(option)}
                    disabled={loading}
                    className={`rounded-full border px-3 py-2 text-sm font-semibold transition ${
                      isActive
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-outline/30 bg-surface-variant text-on-surface"
                    } disabled:cursor-not-allowed disabled:opacity-70`}
                  >
                    {option} cards
                  </button>
                );
              })}
            </div>
          </div>

          <button
            type="button"
            onClick={handleGenerate}
            disabled={loading}
            className="inline-flex h-12 items-center justify-center rounded-xl bg-primary px-6 text-sm font-semibold text-on-primary shadow-lg shadow-primary/30 transition hover:bg-primary/90 disabled:cursor-not-allowed disabled:bg-primary/50"
          >
            {loading ? (
              <span className="inline-flex items-center gap-2">
                <LoadingDots />
                Generating…
              </span>
            ) : (
              "Generate AI Flashcards"
            )}
          </button>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-on-surface">Flashcards</h2>
          {loading && (
            <div className="inline-flex items-center gap-2 text-sm font-medium text-on-surface-variant">
              <LoadingDots />
              <span>AI is preparing your cards…</span>
            </div>
          )}
        </div>

        {history.length > 0 && (
          <div className="rounded-2xl border border-outline/10 bg-surface-variant/30 px-4 py-4">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-on-surface">Recent history</p>
                <p className="text-xs text-on-surface-variant">Jump back into your last flashcard sets.</p>
              </div>
              <span className="text-xs font-medium text-on-surface-variant">{history.length} saved</span>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
              {history.map((entry) => (
                <button
                  type="button"
                  key={entry.id}
                  className="flex flex-col items-start gap-1 rounded-xl border border-outline/20 bg-surface px-3 py-3 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-md"
                  onClick={() => loadHistoryEntry(entry)}
                >
                  <span className="text-xs font-semibold uppercase tracking-wide text-primary">History</span>
                  <span className="text-sm font-bold text-on-surface">{entry.subject}</span>
                  <span className="line-clamp-1 text-xs text-on-surface-variant">{entry.topic || "Untitled topic"}</span>
                  <span className="text-[11px] font-semibold text-on-surface-variant/80">
                    {entry.cards.length} cards • {formatIstDateTime(entry.createdAt)} IST
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {flashcards.length === 0 && !loading && (
          <div className="rounded-xl border border-dashed border-outline/30 bg-surface-variant/40 px-6 py-10 text-center text-on-surface-variant">
            Start by picking a subject and topic, then hit Generate to see AI flashcards here.
          </div>
        )}

        {flashcards.length > 0 && (pendingCount > 0 || skippedCount > 0) && (
          <div className="flex items-center gap-2 rounded-xl bg-surface-variant/40 px-3 py-2 text-sm text-on-surface-variant">
            <IconSparkles size={16} className="text-primary" />
            <span>Tap to flip. Swipe right to mark Known, left for Review. Use arrows to browse cards.</span>
          </div>
        )}

        {flashcards.length > 0 && (
          <div className="flex flex-wrap gap-3 rounded-xl border border-outline/10 bg-surface-variant/30 px-4 py-3 text-xs font-semibold text-on-surface">
            <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-primary">
              Total: {flashcards.length}
            </span>
            <span className="inline-flex items-center gap-2 rounded-full bg-green-100 px-3 py-1 text-green-700">
              Known: {checkedCount}
            </span>
            <span className="inline-flex items-center gap-2 rounded-full bg-error/10 px-3 py-1 text-error">
              Review: {uncheckedCount}
            </span>
            <span className="inline-flex items-center gap-2 rounded-full bg-orange-100 px-3 py-1 text-orange-700">
              Skipped: {skippedCount}
            </span>
            <span className="inline-flex items-center gap-2 rounded-full bg-surface px-3 py-1 text-on-surface-variant">
              Pending: {pendingCount}
            </span>
          </div>
        )}

        {flashcards.length > 0 && (pendingCount > 0 || skippedCount > 0) && (
          <div className="relative h-[520px] w-full">
            {/* Navigation Arrows */}
            <button
              type="button"
              onClick={handlePrevCard}
              disabled={currentCardIndex === 0}
              className="absolute left-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-surface/90 p-3 shadow-lg backdrop-blur transition hover:bg-surface disabled:opacity-30 disabled:cursor-not-allowed"
              aria-label="Previous card"
            >
              <IconChevronLeft size={24} className="text-on-surface" />
            </button>
            <button
              type="button"
              onClick={handleNextCard}
              disabled={currentCardIndex === flashcards.length - 1}
              className="absolute right-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-surface/90 p-3 shadow-lg backdrop-blur transition hover:bg-surface disabled:opacity-30 disabled:cursor-not-allowed"
              aria-label="Next card"
            >
              <IconChevronRight size={24} className="text-on-surface" />
            </button>

            {flashcards.map((card, idx) => {
              if (idx !== currentCardIndex) return null;

              const status = cardStatus[idx] ?? "pending";
              const isFlipped = flipped[idx] ?? false;
              const statusStyles =
                status === "checked"
                  ? "bg-green-100 text-green-700 border-green-300"
                  : status === "unchecked"
                    ? "bg-error/10 text-error border-error/30"
                    : status === "skipped"
                      ? "bg-orange-100 text-orange-700 border-orange-300"
                      : "bg-primary/5 text-primary border-primary/20";

              return (
                <div
                  key={card.question ? `${card.question}-${idx}` : `card-${idx}`}
                  className="absolute left-1/2 top-0 w-full max-w-md -translate-x-1/2 cursor-pointer select-none"
                  style={{
                    height: "calc(100% - 48px)",
                    transform: `translateX(-50%) translateX(${swipeOffset}px)`,
                    transition: isSwiping ? "none" : "transform 0.3s ease-out",
                  }}
                  onTouchStart={handleTouchStart}
                  onTouchMove={handleTouchMove}
                  onTouchEnd={handleTouchEnd}
                  onMouseDown={handleMouseDown}
                  onMouseMove={handleMouseMove}
                  onMouseUp={handleMouseUp}
                  onMouseLeave={handleMouseUp}
                  onClick={handleCardClick}
                >
                  <div
                    className={`absolute inset-0 h-full w-full transition-transform duration-300 [transform-style:preserve-3d] ${
                      isFlipped ? "[transform:rotateY(180deg)]" : ""
                    }`}
                  >
                    <div className="absolute inset-0 flex h-full w-full flex-col gap-3 rounded-2xl border border-outline/20 bg-surface p-6 shadow-lg [backface-visibility:hidden]">
                      <div className="flex items-center justify-between">
                        <span
                          className={`rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide ${statusStyles}`}
                        >
                          {status === "checked"
                            ? "Known"
                            : status === "unchecked"
                              ? "Review"
                              : status === "skipped"
                                ? "Skipped"
                                : "Pending"}
                        </span>
                        <span className="text-xs font-semibold text-primary">
                          Card {idx + 1} of {flashcards.length}
                        </span>
                      </div>
                      <div className="flex-1 overflow-auto rounded-2xl bg-surface-variant/50 p-4 text-on-surface shadow-inner">
                        <h3 className="text-lg font-semibold text-on-surface leading-relaxed">{card.question}</h3>
                      </div>
                      <p className="text-xs text-on-surface-variant">Tap to flip and see the answer</p>
                    </div>

                    <div className="absolute inset-0 flex h-full w-full flex-col gap-3 rounded-2xl border border-outline/20 bg-surface p-6 shadow-lg [backface-visibility:hidden] [transform:rotateY(180deg)]">
                      <div className="flex items-center justify-between">
                        <span
                          className={`rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide ${statusStyles}`}
                        >
                          {status === "checked"
                            ? "Known"
                            : status === "unchecked"
                              ? "Review"
                              : status === "skipped"
                                ? "Skipped"
                                : "Pending"}
                        </span>
                        <span className="text-xs font-semibold text-primary">Answer</span>
                      </div>
                      <div className="flex-1 overflow-auto rounded-2xl bg-surface-variant/50 p-4 text-on-surface shadow-inner">
                        <p className="text-base leading-relaxed text-on-surface">{card.answer}</p>
                      </div>
                      {card.hint && (
                        <div className="rounded-lg bg-primary/5 px-3 py-2">
                          <p className="text-sm text-primary">
                            <span className="font-semibold">Hint:</span> {card.hint}
                          </p>
                        </div>
                      )}
                      <p className="text-xs text-on-surface-variant">Tap to flip back</p>
                    </div>
                  </div>

                  <div className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-4 rounded-b-2xl bg-surface/95 px-4 py-3 shadow-lg backdrop-blur">
                    <button
                      type="button"
                      className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-error/40 bg-error/10 text-error transition hover:bg-error/15"
                      onClick={(e) => {
                        e.stopPropagation();
                        markCard(idx, "unchecked");
                      }}
                      title="Need Review"
                      aria-label="Mark for review"
                    >
                      <IconXMark size={24} />
                    </button>
                    <button
                      type="button"
                      className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-green-300 bg-green-100 text-green-700 transition hover:bg-green-200"
                      onClick={(e) => {
                        e.stopPropagation();
                        markCard(idx, "checked");
                      }}
                      title="Got It"
                      aria-label="Mark as known"
                    >
                      <IconCheck size={24} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {flashcards.length > 0 && (pendingCount === 0 && skippedCount === 0) && (
          <div className="rounded-2xl border border-outline/10 bg-surface shadow-ambient px-6 py-8 text-center space-y-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-2">
              <IconCheck size={32} className="text-primary" />
            </div>
            <h3 className="text-xl font-bold text-on-surface">Session Complete!</h3>
            <p className="text-on-surface-variant">You&apos;ve reviewed all flashcards in this set.</p>

            {/* Pie Chart */}
            <div className="flex items-center justify-center gap-8">
              <svg width="120" height="120" viewBox="0 0 120 120" className="transform -rotate-90">
                <circle cx="60" cy="60" r="50" fill="none" stroke="#e5e7eb" strokeWidth="20" />
                {(() => {
                  const total = flashcards.length;
                  const knownPercent = (checkedCount / total) * 100;
                  const reviewPercent = (uncheckedCount / total) * 100;
                  const circumference = 2 * Math.PI * 50;
                  const knownOffset = 0;
                  const reviewOffset = (knownPercent / 100) * circumference;

                  return (
                    <>
                      {/* Known slice (green) */}
                      {checkedCount > 0 && (
                        <circle
                          cx="60"
                          cy="60"
                          r="50"
                          fill="none"
                          stroke="#86efac"
                          strokeWidth="20"
                          strokeDasharray={`${(knownPercent / 100) * circumference} ${circumference}`}
                          strokeDashoffset={-knownOffset}
                        />
                      )}
                      {/* Review slice (red) */}
                      {uncheckedCount > 0 && (
                        <circle
                          cx="60"
                          cy="60"
                          r="50"
                          fill="none"
                          stroke="#fca5a5"
                          strokeWidth="20"
                          strokeDasharray={`${(reviewPercent / 100) * circumference} ${circumference}`}
                          strokeDashoffset={-reviewOffset}
                        />
                      )}
                    </>
                  );
                })()}
              </svg>
              <div className="text-left space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-green-300"></div>
                  <span className="text-sm text-on-surface">Known: {checkedCount} ({Math.round((checkedCount / flashcards.length) * 100)}%)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-red-300"></div>
                  <span className="text-sm text-on-surface">Review: {uncheckedCount} ({Math.round((uncheckedCount / flashcards.length) * 100)}%)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-orange-200"></div>
                  <span className="text-sm text-on-surface">Skipped: {skippedCount}</span>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-outline/10 bg-surface-variant/40 px-4 py-4 text-sm text-on-surface">
              <div className="flex flex-wrap items-center justify-center gap-4">
                <span className="font-semibold">Session summary</span>
                <span className="rounded-full bg-primary/10 px-3 py-1 text-primary">
                  Total cards: {flashcards.length}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-surface px-3 py-1 text-on-surface-variant">
                  Reviewed: {reviewedCount}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-3 py-1 text-green-700">
                  <IconCheck size={16} />
                  Known: {checkedCount}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-error/10 px-3 py-1 text-error">
                  <IconXMark size={16} />
                  Review: {uncheckedCount}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
