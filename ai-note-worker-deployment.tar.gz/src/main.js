require("tsx/cjs");
require("tsconfig-paths/register");

const { processAiGenerationJob } = require("./lib/ai-generation-worker.ts");

function parsePayload(req) {
  const raw = req?.bodyRaw ?? req?.body ?? "";
  if (!raw) return {};
  if (typeof raw === "object") return raw;
  const text = String(raw).trim();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}

function respond(res, status, payload) {
  if (res && typeof res.json === "function") {
    return res.json(payload, status);
  }
  if (res && typeof res.send === "function") {
    return res.send(JSON.stringify(payload), status, { "content-type": "application/json" });
  }
  return payload;
}

module.exports = async (context) => {
  const req = context?.req ?? context;
  const res = context?.res;
  const log = context?.log ?? console.log;
  const error = context?.error ?? console.error;

  const payload = parsePayload(req);
  const jobId = typeof payload?.jobId === "string" ? payload.jobId.trim() : "";
  if (!jobId) {
    return respond(res, 400, { ok: false, error: "Missing jobId in execution payload." });
  }

  try {
    await processAiGenerationJob(jobId);
    log(`[ai-note-worker] Completed job ${jobId}`);
    return respond(res, 200, { ok: true, jobId });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown worker failure";
    error(`[ai-note-worker] Failed job ${jobId}: ${message}`);
    return respond(res, 500, { ok: false, jobId, error: message });
  }
};
