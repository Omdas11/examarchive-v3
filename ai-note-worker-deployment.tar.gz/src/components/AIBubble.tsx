"use client";

import { useState, useRef, useEffect, type ReactNode } from "react";
import Link from "next/link";

interface Message {
  role: "user" | "model";
  text: string;
  model?: string;
  sources?: string[];
}

interface AIBubbleProps {
  /** Whether the current user is logged in. */
  isLoggedIn: boolean;
}

const LOADING_DOT_STATES = [".", "..", "..."];
const ROUTE_PATH_PATTERN = /(^|\s)(\/[a-zA-Z0-9_-]+(?:\/[a-zA-Z0-9_-]+)*)/g;
const STRICT_ROUTE_PATTERN = /^\/[a-zA-Z0-9_-]+(?:\/[a-zA-Z0-9_-]+)*$/;

export default function AIBubble({ isLoggedIn }: AIBubbleProps) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [loadingDots, setLoadingDots] = useState(".");
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (open && bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, open]);

  // Focus input when panel opens
  useEffect(() => {
    if (open && inputRef.current) {
      inputRef.current.focus();
    }
  }, [open]);

  // Greeting on first open
  useEffect(() => {
    if (open && messages.length === 0 && isLoggedIn) {
      setMessages([
        {
          role: "model",
          text: "👋 Hi! I'm ExamBot. I can help you navigate ExamArchive, find past papers, and answer academic questions. What can I help you with today?",
        },
      ]);
    }
  }, [open, messages.length, isLoggedIn]);

  // Animated loading dots
  useEffect(() => {
    if (!loading) {
      setLoadingDots(".");
      return;
    }
    let index = 0;
    const timer = window.setInterval(() => {
      index = (index + 1) % LOADING_DOT_STATES.length;
      setLoadingDots(LOADING_DOT_STATES[index]);
    }, 300);
    return () => window.clearInterval(timer);
  }, [loading]);

  async function sendMessage() {
    const trimmed = input.trim();
    if (!trimmed || loading) return;

    const newMessages: Message[] = [...messages, { role: "user", text: trimmed }];
    setMessages(newMessages);
    setInput("");
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: trimmed,
          history: messages.slice(-10).map((m) => ({
            role: m.role,
            text: m.text,
          })),
        }),
      });

      const data = (await res.json()) as {
        reply?: string;
        error?: string;
        model?: string;
        sources?: string[];
      };
      if (!res.ok) {
        setError(data.error ?? "Something went wrong.");
      } else {
        const reply = data.reply?.trim();
        if (!reply) {
          setError("Service temporarily unavailable. Please try again shortly.");
        } else {
          setMessages((prev) => [
            ...prev,
            {
              role: "model",
              text: reply,
              model: data.model,
              sources: Array.isArray(data.sources) ? data.sources.slice(0, 4) : [],
            },
          ]);
        }
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  function renderRichText(text: string) {
    const nodes: ReactNode[] = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;
    ROUTE_PATH_PATTERN.lastIndex = 0;
    while ((match = ROUTE_PATH_PATTERN.exec(text)) !== null) {
      const [, leading = "", route = ""] = match;
      const matchStart = match.index;
      const routeStart = matchStart + leading.length;
      if (routeStart > lastIndex) {
        nodes.push(<span key={`text-${lastIndex}`}>{text.slice(lastIndex, routeStart)}</span>);
      }
      const routeEnd = routeStart + route.length;
      const prevWindow = text.slice(Math.max(0, routeStart - 12), routeStart).toLowerCase();
      const nextChar = text[routeEnd] ?? "";
      const looksLikeExternalUrl = prevWindow.includes("://") || prevWindow.endsWith("www.");
      const hasExternalDomainTail = nextChar === ".";
      if (STRICT_ROUTE_PATTERN.test(route) && route.length > 1 && !looksLikeExternalUrl && !hasExternalDomainTail) {
        nodes.push(
          <Link key={`route-${routeStart}`} href={route} style={{ color: "inherit", textDecoration: "underline" }}>
            {route}
          </Link>,
        );
      } else {
        nodes.push(<span key={`raw-${routeStart}`}>{route}</span>);
      }
      lastIndex = routeEnd;
    }
    if (lastIndex < text.length) {
      nodes.push(<span key={`tail-${lastIndex}`}>{text.slice(lastIndex)}</span>);
    }
    return nodes;
  }

  return (
    <>
      {/* ── Floating bubble button ─────────────────────────────────────────── */}
      <button
        aria-label={open ? "Close AI assistant" : "Open AI assistant"}
        onClick={() => {
          if (!isLoggedIn) {
            window.location.href = "/login?next=/";
            return;
          }
          setOpen((v) => !v);
        }}
        style={{
          position: "fixed",
          bottom: "5.5rem",
          right: "1.25rem",
          zIndex: 200,
          width: 52,
          height: 52,
          borderRadius: "50%",
          border: "none",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 24,
          background: "linear-gradient(135deg, var(--brand-crimson), var(--nav-teal))",
          color: "#fff",
          boxShadow: "0 4px 16px rgba(0,0,0,0.25)",
          transition: "transform 0.2s, box-shadow 0.2s",
        }}
        onMouseEnter={(e) => {
          (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.1)";
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLButtonElement).style.transform = "scale(1)";
        }}
      >
        {open ? "✕" : "💭"}
      </button>

      {/* ── Chat panel ────────────────────────────────────────────────────── */}
      {open && isLoggedIn && (
        <div
          role="dialog"
          aria-label="AI assistant chat panel"
          style={{
            position: "fixed",
            bottom: "8.5rem",
            right: "1.25rem",
            zIndex: 199,
            width: "min(360px, calc(100vw - 2rem))",
            maxHeight: "min(520px, calc(100dvh - 10rem))",
            display: "flex",
            flexDirection: "column",
            background: "var(--color-surface)",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius-lg)",
            boxShadow: "0 8px 32px rgba(0,0,0,0.18)",
            overflow: "hidden",
          }}
        >
          {/* Header */}
          <div
            style={{
              padding: "0.75rem 1rem",
              borderBottom: "1px solid var(--color-border)",
              background: "linear-gradient(135deg, var(--brand-crimson), var(--nav-teal))",
              color: "#fff",
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
              flexShrink: 0,
            }}
          >
            <span style={{ fontSize: 18 }}>💭</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: "0.875rem" }}>ExamBot</div>
              <div style={{ fontSize: "0.7rem", opacity: 0.85 }}>AI Academic Assistant</div>
            </div>
            <button
              aria-label="Clear chat history"
              onClick={() => setMessages([])}
              style={{
                marginLeft: "auto",
                background: "transparent",
                border: "none",
                color: "#fff",
                cursor: "pointer",
                fontSize: "0.7rem",
                opacity: 0.8,
                padding: "2px 6px",
              }}
              title="Clear history"
            >
              Clear
            </button>
          </div>

          {/* Messages */}
          <div
            style={{
              flex: 1,
              overflowY: "auto",
              padding: "0.75rem",
              display: "flex",
              flexDirection: "column",
              gap: "0.6rem",
            }}
          >
            {messages.length === 0 && (
              <p style={{ color: "var(--color-text-muted)", fontSize: "0.8rem", textAlign: "center", marginTop: "1rem" }}>
                Ask me anything about ExamArchive!
              </p>
            )}
            {messages.map((m, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  justifyContent: m.role === "user" ? "flex-end" : "flex-start",
                }}
              >
                <div
                  style={{
                    maxWidth: "85%",
                    padding: "0.5rem 0.75rem",
                    borderRadius: m.role === "user" ? "12px 12px 2px 12px" : "12px 12px 12px 2px",
                    background:
                      m.role === "user"
                        ? "var(--brand-crimson)"
                        : "var(--color-accent-soft)",
                    color: m.role === "user" ? "#fff" : "var(--color-text)",
                    fontSize: "0.8rem",
                    lineHeight: 1.5,
                    whiteSpace: "pre-wrap",
                    wordBreak: "break-word",
                  }}
                >
                  {renderRichText(m.text)}
                  {m.role === "model" && (m.model || (m.sources && m.sources.length > 0)) && (
                    <div style={{ marginTop: 8, fontSize: "0.68rem", opacity: 0.85 }}>
                      {m.model && <div>Model: {m.model}</div>}
                      {m.sources && m.sources.length > 0 && (
                        <div>
                          Sources:{" "}
                          {m.sources.map((source, index) => (
                            <a
                              key={`${source}-${index}`}
                              href={source}
                              target="_blank"
                              rel="noreferrer noopener"
                              style={{ color: "inherit", textDecoration: "underline", marginRight: 6 }}
                            >
                              [{index + 1}]
                            </a>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div style={{ display: "flex", justifyContent: "flex-start" }}>
                <div
                  style={{
                    padding: "0.5rem 0.75rem",
                    borderRadius: "12px 12px 12px 2px",
                    background: "var(--color-accent-soft)",
                    fontSize: "0.8rem",
                    color: "var(--color-text-muted)",
                  }}
                >
                  ExamBot is thinking{loadingDots}
                </div>
              </div>
            )}
            {error && (
              <div
                style={{
                  padding: "0.4rem 0.6rem",
                  borderRadius: 6,
                  background: "#fce8eb",
                  color: "var(--brand-crimson)",
                  fontSize: "0.75rem",
                }}
              >
                {error}
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input area */}
          <div
            style={{
              padding: "0.6rem",
              borderTop: "1px solid var(--color-border)",
              display: "flex",
              gap: "0.4rem",
              flexShrink: 0,
            }}
          >
            <input
              ref={inputRef}
              type="text"
              placeholder="Ask ExamBot…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              maxLength={1000}
              disabled={loading}
              style={{
                flex: 1,
                padding: "0.45rem 0.65rem",
                fontSize: "0.8rem",
                border: "1px solid var(--color-border)",
                borderRadius: "var(--radius-sm)",
                background: "var(--color-input-bg)",
                color: "var(--color-text)",
                outline: "none",
              }}
            />
            <button
              onClick={sendMessage}
              disabled={loading || !input.trim()}
              style={{
                padding: "0.45rem 0.85rem",
                fontSize: "0.8rem",
                fontWeight: 600,
                borderRadius: "var(--radius-sm)",
                border: "none",
                cursor: loading || !input.trim() ? "not-allowed" : "pointer",
                background: "var(--brand-crimson)",
                color: "#fff",
                opacity: loading || !input.trim() ? 0.6 : 1,
                transition: "opacity 0.15s",
              }}
            >
              Send
            </button>
          </div>
        </div>
      )}
    </>
  );
}
