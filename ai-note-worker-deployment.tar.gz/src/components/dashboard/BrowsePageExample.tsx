/**
 * Browse Page Example
 * Demonstrates using layout and dashboard components for a listing page
 *
 * This is a template example showing how to integrate the new
 * Digital Curator components into existing pages.
 */

'use client';

import React, { useEffect, useState } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { cn } from '@/lib/utils';

const SIDEBAR_ITEMS = [
  {
    label: 'Dashboard',
    icon: 'dashboard',
    href: '/dashboard',
  },
  {
    label: 'Browse Papers',
    icon: 'library_books',
    href: '/browse',
  },
  {
    label: 'My Collections',
    icon: 'bookmark',
    href: '/collections',
    badge: 3,
  },
  {
    label: 'Upload Paper',
    icon: 'upload_file',
    href: '/upload',
  },
  {
    label: 'My Profile',
    icon: 'person',
    href: '/profile',
  },
];

interface PaperItem {
  id: string;
  title: string;
  author: string;
  course: string;
  year: number;
  views: number;
  downloads: number;
  verified: boolean;
  university: string;
  category: string;
}

type PaperApiItem = Partial<PaperItem> & {
  $id?: string;
  uploaded_by_username?: string;
  course_name?: string;
  course_code?: string;
  view_count?: number;
  download_count?: number;
  approved?: boolean;
  institution?: string;
  department?: string;
  paper_type?: string;
};

export default function BrowsePageExample() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState('trending');
  const [searchQuery, setSearchQuery] = useState('');
  const [papers, setPapers] = useState<PaperItem[]>([]);
  const [loading, setLoading] = useState(true);

  const categories = ['All', 'Question Paper', 'Lecture Notes', 'Research Papers', 'Tutorial', 'Exam Papers'];

  useEffect(() => {
    async function loadPapers() {
      try {
        const res = await fetch('/api/papers');
        const docs = (await res.json()) as PaperApiItem[];
        const mapped = docs.map((doc) => ({
          id: doc.id ?? doc.$id ?? "",
          title: doc.title ?? doc.course ?? "Paper",
          author: doc.author ?? doc.uploaded_by_username ?? "Unknown",
          course: doc.course ?? doc.course_name ?? doc.course_code ?? "Course",
          year: doc.year ?? 0,
          views: doc.views ?? doc.view_count ?? 0,
          downloads: doc.downloads ?? doc.download_count ?? 0,
          verified: doc.verified ?? doc.approved ?? false,
          university: doc.university ?? doc.institution ?? doc.department ?? "Unknown",
          category: doc.category ?? doc.paper_type ?? "Question Paper",
        }));
        setPapers(mapped);
      } catch {
        setPapers([]);
      } finally {
        setLoading(false);
      }
    }
    loadPapers();
  }, []);

  const filteredPapers = papers.filter(paper => {
    const matchesCategory = !selectedCategory || paper.category === selectedCategory;
    const matchesSearch = !searchQuery || 
      paper.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      paper.author.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const sortedPapers = [...filteredPapers].sort((a, b) => {
    if (sortBy === 'trending') return (b.views || 0) - (a.views || 0);
    if (sortBy === 'popular') return (b.downloads || 0) - (a.downloads || 0);
    if (sortBy === 'recent') return (b.year || 0) - (a.year || 0);
    return 0;
  });

  return (
    <MainLayout
      title="Browse Papers"
      breadcrumbs={[
        { label: 'Home', href: '/dashboard' },
        { label: 'Browse Papers' }
      ]}
      showSearch
      userInitials="JD"
      userName="John Doe"
      sidebarItems={SIDEBAR_ITEMS}
      userRole="user"
      onSearch={(query) => setSearchQuery(query)}
    >
      {/* Browse Header Section */}
      <div className="bg-gradient-to-r from-primary/10 via-secondary/5 to-transparent border-b border-outline-variant/10">
        <div className="p-6 space-y-4 max-w-7xl">
          <div>
            <h1 className="text-3xl font-bold text-on-surface mb-2">
              Explore Academic Papers
            </h1>
            <p className="text-on-surface-variant">
              Discover verified papers, notes, and resources from curators worldwide
            </p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center gap-3 p-3 bg-surface/50 rounded-lg">
              <span className="material-symbols-outlined text-primary text-2xl">
                library_books
              </span>
              <div>
                <p className="text-xs text-on-surface-variant">Total Papers</p>
                <p className="text-lg font-bold text-on-surface">12,847</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-surface/50 rounded-lg">
              <span className="material-symbols-outlined text-secondary text-2xl">
                verified
              </span>
              <div>
                <p className="text-xs text-on-surface-variant">Verified</p>
                <p className="text-lg font-bold text-on-surface">98.5%</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-surface/50 rounded-lg">
              <span className="material-symbols-outlined text-tertiary text-2xl">
                star
              </span>
              <div>
                <p className="text-xs text-on-surface-variant">Daily Downloads</p>
                <p className="text-lg font-bold text-on-surface">2,341</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 max-w-7xl">
        {/* Filters & Sort */}
        <div className="space-y-4 mb-8">
          {/* Category Filters */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat === 'All' ? null : cat)}
                className={cn(
                  'px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap',
                  'transition-all duration-200',
                  (selectedCategory === cat || (cat === 'All' && !selectedCategory))
                    ? 'gradient-primary text-on-primary shadow-lift'
                    : 'bg-surface-container-low text-on-surface hover:bg-surface-container'
                )}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Sort Options */}
          <div className="flex items-center justify-between">
            <p className="text-sm text-on-surface-variant">
              Showing {sortedPapers.length} results
            </p>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className={cn(
                'px-3 py-2 rounded-lg text-sm',
                'bg-surface-container-low border border-outline-variant/20',
                'text-on-surface font-medium',
                'hover:bg-surface-container transition-colors',
                'outline-none cursor-pointer'
              )}
            >
              <option value="trending">Trending</option>
              <option value="popular">Most Downloaded</option>
              <option value="recent">Most Recent</option>
            </select>
          </div>
        </div>

        {/* Papers Grid */}
        {loading ? (
          <div className="text-center py-12">
            <span className="material-symbols-outlined text-5xl text-on-surface-variant/40 mx-auto block mb-4">
              hourglass_top
            </span>
            <p className="text-on-surface-variant">Loading papers…</p>
          </div>
        ) : sortedPapers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedPapers.map(paper => (
              <div
                key={paper.id}
                className={cn(
                  'p-5 rounded-xl bg-surface-container-low',
                  'border border-outline-variant/10',
                  'hover:shadow-lift hover:bg-surface-container',
                  'transition-all duration-200 group cursor-pointer'
                )}
              >
                {/* Header */}
                <div className="mb-3">
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-xs font-bold uppercase bg-primary/10 text-primary px-2 py-1 rounded-full">
                      {paper.category}
                    </span>
                    {paper.verified && (
                      <span className="material-symbols-outlined text-secondary text-lg">
                        verified
                      </span>
                    )}
                  </div>
                  <h3 className="font-bold text-on-surface line-clamp-2 group-hover:text-primary transition-colors">
                    {paper.title}
                  </h3>
                </div>

                {/* Metadata */}
                <div className="space-y-2 mb-4 text-sm">
                  <p className="text-on-surface-variant">
                    <span className="font-semibold">By:</span> {paper.author}
                  </p>
                  <p className="text-on-surface-variant text-xs">
                    {paper.university} • {paper.year}
                  </p>
                  <p className="text-on-surface-variant text-xs">
                    {paper.course}
                  </p>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 py-3 border-t border-outline-variant/10 text-xs font-bold text-on-surface-variant">
                  <span className="flex items-center gap-1">
                    <span className="material-symbols-outlined text-sm">visibility</span>
                    {paper.views}
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="material-symbols-outlined text-sm">download</span>
                    {paper.downloads}
                  </span>
                </div>

                {/* Action Button */}
                <button
                  className={cn(
                    'w-full mt-3 px-4 py-2',
                    'gradient-primary text-on-primary rounded-lg',
                    'font-bold text-sm',
                    'hover:opacity-90 transition-opacity',
                    'group-hover:scale-105 transition-transform'
                  )}
                >
                  Read Paper
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <span className="material-symbols-outlined text-5xl text-on-surface-variant/40 mx-auto block mb-4">
              search
            </span>
            <h3 className="text-lg font-bold text-on-surface mb-2">No papers found</h3>
            <p className="text-on-surface-variant">
              Try adjusting your filters or search query
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
